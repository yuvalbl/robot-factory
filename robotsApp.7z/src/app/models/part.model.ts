export class Part {
  id: number;
  name: string;
  type: string;
  engine: string;
  cpu: string;
}
